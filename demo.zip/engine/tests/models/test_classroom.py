# tests/models/test_classroom.py

from engine.models.classroom import Classroom


def test_classroom_creation():
    room = Classroom(
        room_no="101",
        rows=5,
        benches_per_row=3,
    )

    assert room.room_no == "101"
    assert room.rows == 5
    assert room.benches_per_row == 3
    assert room.seats_per_bench == 3


def test_default_seats_per_bench():
    room = Classroom(
        room_no="102",
        rows=5,
        benches_per_row=3,
    )

    assert room.seats_per_bench == 3


def test_custom_seats_per_bench():
    room = Classroom(
        room_no="103",
        rows=5,
        benches_per_row=3,
        seats_per_bench=2,
    )

    assert room.seats_per_bench == 2


def test_capacity_standard_room():
    room = Classroom(
        room_no="101",
        rows=5,
        benches_per_row=3,
    )

    assert room.capacity == 45


def test_capacity_custom_room():
    room = Classroom(
        room_no="102",
        rows=6,
        benches_per_row=4,
    )

    assert room.capacity == 72


def test_capacity_custom_seats():
    room = Classroom(
        room_no="103",
        rows=6,
        benches_per_row=4,
        seats_per_bench=2,
    )

    assert room.capacity == 48


def test_column_capacity_standard():
    room = Classroom(
        room_no="101",
        rows=5,
        benches_per_row=3,
    )

    assert room.column_capacity == 15


def test_column_capacity_custom():
    room = Classroom(
        room_no="102",
        rows=6,
        benches_per_row=4,
    )

    assert room.column_capacity == 24


def test_capacity_is_positive():
    room = Classroom(
        room_no="101",
        rows=5,
        benches_per_row=3,
    )

    assert room.capacity > 0


def test_column_capacity_is_positive():
    room = Classroom(
        room_no="101",
        rows=5,
        benches_per_row=3,
    )

    assert room.column_capacity > 0


def test_capacity_formula():
    room = Classroom(
        room_no="201",
        rows=8,
        benches_per_row=5,
        seats_per_bench=3,
    )

    expected = 8 * 5 * 3

    assert room.capacity == expected


def test_column_capacity_formula():
    room = Classroom(
        room_no="201",
        rows=8,
        benches_per_row=5,
    )

    expected = 8 * 5

    assert room.column_capacity == expected


def test_small_room():
    room = Classroom(
        room_no="Small",
        rows=2,
        benches_per_row=2,
    )

    assert room.capacity == 12
    assert room.column_capacity == 4


def test_large_room():
    room = Classroom(
        room_no="Auditorium",
        rows=20,
        benches_per_row=10,
    )

    assert room.capacity == 600
    assert room.column_capacity == 200