# tests/models/test_remaining_pool.py

import pytest

from engine.models.remaining_pool import RemainingPool
from engine.tests.conftest import build_group


# -------------------------------------------------------
# Test 1 – Pool starts empty
# -------------------------------------------------------

def test_pool_is_empty_initially():
    pool = RemainingPool()
    assert pool.is_empty() is True
    assert pool.groups == []


# -------------------------------------------------------
# Test 2 – Add a group
# -------------------------------------------------------

def test_add_group():
    pool = RemainingPool()
    group = build_group("ME", 10)
    pool.add(group)
    assert group in pool.groups
    assert not pool.is_empty()


# -------------------------------------------------------
# Test 3 – Duplicate add is idempotent
# -------------------------------------------------------

def test_add_duplicate_is_idempotent():
    pool = RemainingPool()
    group = build_group("ME", 10)
    pool.add(group)
    pool.add(group)
    assert pool.groups.count(group) == 1


# -------------------------------------------------------
# Test 4 – Remove a group
# -------------------------------------------------------

def test_remove_group():
    pool = RemainingPool()
    group = build_group("ME", 10)
    pool.add(group)
    pool.remove(group)
    assert group not in pool.groups
    assert pool.is_empty()


# -------------------------------------------------------
# Test 5 – Remove non-existent group is safe
# -------------------------------------------------------

def test_remove_nonexistent_is_safe():
    pool = RemainingPool()
    group = build_group("ME", 10)
    pool.remove(group)   # should not raise


# -------------------------------------------------------
# Test 6 – Multiple groups tracked independently
# -------------------------------------------------------

def test_multiple_groups():
    pool = RemainingPool()
    g1 = build_group("ME", 10)
    g2 = build_group("CE", 5)
    pool.add(g1)
    pool.add(g2)
    assert len(pool.groups) == 2
    pool.remove(g1)
    assert g1 not in pool.groups
    assert g2 in pool.groups


# -------------------------------------------------------
# Test 7 – is_empty after all groups removed
# -------------------------------------------------------

def test_is_empty_after_all_removed():
    pool = RemainingPool()
    g = build_group("EE", 15)
    pool.add(g)
    pool.remove(g)
    assert pool.is_empty()
