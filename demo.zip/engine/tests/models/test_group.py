# tests/models/test_group.py

from engine.tests.conftest import build_group


def test_group_strength():
    group = build_group("ME", 30)

    assert group.strength == 30


def test_remaining_count_initial():
    group = build_group("ME", 30)

    assert group.remaining_count == 30


def test_next_start_index_initial():
    group = build_group("ME", 30)

    assert group.next_start_index == 0


def test_allocate_students():
    group = build_group("ME", 30)

    allocated = group.allocate_students(15)

    assert len(allocated) == 15
    assert group.allocated_count == 15
    assert group.remaining_count == 15
    assert group.next_start_index == 15


def test_allocate_remaining():
    group = build_group("ME", 30)

    first = group.allocate_students(15)
    second = group.allocate_students(15)

    assert len(first) == 15
    assert len(second) == 15

    assert group.allocated_count == 30
    assert group.remaining_count == 0


def test_allocate_more_than_available():
    group = build_group("ME", 10)

    allocated = group.allocate_students(15)

    assert len(allocated) == 10
    assert group.allocated_count == 10
    assert group.remaining_count == 0


def test_allocate_zero_students():
    group = build_group("ME", 25)

    allocated = group.allocate_students(0)

    assert allocated == []
    assert group.allocated_count == 0
    assert group.remaining_count == 25


def test_allocate_after_group_finished():
    group = build_group("ME", 10)

    group.allocate_students(10)

    allocated = group.allocate_students(5)

    assert allocated == []
    assert group.allocated_count == 10
    assert group.remaining_count == 0


def test_priority_equals_remaining_count():
    group = build_group("ME", 40)

    group.allocate_students(15)

    assert group.priority == 25


def test_students_allocated_in_correct_order():
    group = build_group("ME", 20)

    allocated = group.allocate_students(5)

    assert allocated[0].register_no == "ME001"
    assert allocated[1].register_no == "ME002"
    assert allocated[2].register_no == "ME003"
    assert allocated[3].register_no == "ME004"
    assert allocated[4].register_no == "ME005"


def test_second_allocation_continues_from_previous():
    group = build_group("ME", 20)

    group.allocate_students(5)

    allocated = group.allocate_students(5)

    assert allocated[0].register_no == "ME006"
    assert allocated[-1].register_no == "ME010"


def test_multiple_allocations_until_empty():
    group = build_group("ME", 30)

    total = 0

    while group.remaining_count > 0:
        students = group.allocate_students(7)
        total += len(students)

    assert total == 30
    assert group.remaining_count == 0
    assert group.allocated_count == 30


def test_department_information_preserved():
    group = build_group("CS", 15)

    assert group.department == "CS"
    assert group.subject_code == "CS301"
    assert group.session == "FN"


def test_strength_does_not_change_after_allocation():
    group = build_group("ME", 50)

    group.allocate_students(20)

    assert group.strength == 50
    assert group.remaining_count == 30