import pytest

from engine.models.classroom import Classroom
from engine.models.room_allocation import RoomAllocation


class DummyAllocation:
    """
    Fake Allocation object used only for testing.
    """

    def __init__(self, stream, allocated_count):
        self.stream = stream
        self.allocated_count = allocated_count


@pytest.fixture
def room():
    classroom = Classroom(
        room_no="101",
        rows=5,
        benches_per_row=3,
    )
    return RoomAllocation(classroom)


def test_room_initialization(room):
    assert room.classroom.room_no == "101"
    assert room.allocations == []

    assert room.streams["A"] is None
    assert room.streams["B"] is None
    assert room.streams["C"] is None


def test_used_capacity_initial(room):
    assert room.used_capacity == 0


def test_remaining_capacity_initial(room):
    assert room.remaining_capacity == 45


def test_stream_capacity(room):
    assert room.stream_capacity == 15


def test_add_single_allocation(room):
    allocation = DummyAllocation("A", 15)

    room.add_allocation(allocation)

    assert len(room.allocations) == 1
    assert room.streams["A"] == allocation


def test_used_capacity_after_one_allocation(room):
    room.add_allocation(DummyAllocation("A", 15))

    assert room.used_capacity == 15
    assert room.remaining_capacity == 30


def test_multiple_allocations(room):
    room.add_allocation(DummyAllocation("A", 15))
    room.add_allocation(DummyAllocation("B", 15))
    room.add_allocation(DummyAllocation("C", 10))

    assert room.used_capacity == 40
    assert room.remaining_capacity == 5


def test_available_streams_initial(room):
    streams = list(room.available_streams())

    assert streams == ["A", "B", "C"]


def test_available_streams_after_one(room):
    room.add_allocation(DummyAllocation("A", 15))

    streams = list(room.available_streams())

    assert streams == ["B", "C"]


def test_available_streams_after_two(room):
    room.add_allocation(DummyAllocation("A", 15))
    room.add_allocation(DummyAllocation("B", 15))

    streams = list(room.available_streams())

    assert streams == ["C"]


def test_available_streams_after_full(room):
    room.add_allocation(DummyAllocation("A", 15))
    room.add_allocation(DummyAllocation("B", 15))
    room.add_allocation(DummyAllocation("C", 15))

    streams = list(room.available_streams())

    assert streams == []


def test_stream_mapping(room):
    a = DummyAllocation("A", 15)
    b = DummyAllocation("B", 10)

    room.add_allocation(a)
    room.add_allocation(b)

    assert room.streams["A"] is a
    assert room.streams["B"] is b
    assert room.streams["C"] is None