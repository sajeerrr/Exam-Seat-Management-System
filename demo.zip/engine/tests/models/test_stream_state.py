import pytest

from engine.models.classroom import Classroom
from engine.models.room_allocation import RoomAllocation
from engine.models.stream_state import StreamState


class DummyAllocation:
    def __init__(self, stream, allocated_count):
        self.stream = stream
        self.allocated_count = allocated_count


@pytest.fixture
def room():
    classroom = Classroom(
        room_no="101",
        rows=5,
        benches_per_row=3,
    )
    return RoomAllocation(classroom)


def test_stream_initial(room):
    stream = StreamState(
        room=room,
        stream="A",
        capacity=15,
    )

    assert stream.is_available
    assert stream.used_capacity == 0
    assert stream.remaining_capacity == 15


def test_stream_after_allocation(room):
    allocation = DummyAllocation("A", 15)

    room.add_allocation(allocation)

    stream = StreamState(
        room=room,
        stream="A",
        capacity=15,
    )

    assert stream.allocation == allocation
    assert stream.is_available is False
    assert stream.used_capacity == 15
    assert stream.remaining_capacity == 0


def test_partial_allocation(room):
    allocation = DummyAllocation("B", 8)

    room.add_allocation(allocation)

    stream = StreamState(
        room=room,
        stream="B",
        capacity=15,
    )

    assert stream.used_capacity == 8
    assert stream.remaining_capacity == 7


def test_empty_stream(room):
    stream = StreamState(
        room=room,
        stream="C",
        capacity=15,
    )

    assert stream.allocation is None
    assert stream.is_available
    assert stream.used_capacity == 0
    assert stream.remaining_capacity == 15


def test_multiple_streams(room):
    room.add_allocation(DummyAllocation("A", 15))
    room.add_allocation(DummyAllocation("B", 10))

    stream_a = StreamState(room, "A", 15)
    stream_b = StreamState(room, "B", 15)
    stream_c = StreamState(room, "C", 15)

    assert stream_a.used_capacity == 15
    assert stream_b.used_capacity == 10
    assert stream_c.used_capacity == 0

    assert stream_a.remaining_capacity == 0
    assert stream_b.remaining_capacity == 5
    assert stream_c.remaining_capacity == 15