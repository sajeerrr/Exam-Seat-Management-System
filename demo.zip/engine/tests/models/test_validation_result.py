# tests/models/test_validation_result.py

import pytest

from engine.models.validation_result import ValidationResult


# -------------------------------------------------------
# Test 1 – Default state is success with no messages
# -------------------------------------------------------

def test_default_is_success():
    result = ValidationResult()
    assert result.success is True
    assert result.errors == []
    assert result.warnings == []


# -------------------------------------------------------
# Test 2 – add_error sets success=False
# -------------------------------------------------------

def test_add_error_sets_failure():
    result = ValidationResult()
    result.add_error("Something went wrong")
    assert result.success is False


# -------------------------------------------------------
# Test 3 – add_error appends to errors list
# -------------------------------------------------------

def test_add_error_appends_message():
    result = ValidationResult()
    result.add_error("Error A")
    result.add_error("Error B")
    assert "Error A" in result.errors
    assert "Error B" in result.errors
    assert len(result.errors) == 2


# -------------------------------------------------------
# Test 4 – add_warning does not affect success
# -------------------------------------------------------

def test_add_warning_does_not_affect_success():
    result = ValidationResult()
    result.add_warning("Minor issue")
    assert result.success is True


# -------------------------------------------------------
# Test 5 – add_warning appends to warnings list
# -------------------------------------------------------

def test_add_warning_appends_message():
    result = ValidationResult()
    result.add_warning("Warning X")
    assert "Warning X" in result.warnings


# -------------------------------------------------------
# Test 6 – Errors and warnings are independent lists
# -------------------------------------------------------

def test_errors_and_warnings_independent():
    result = ValidationResult()
    result.add_error("Err 1")
    result.add_warning("Warn 1")
    assert len(result.errors) == 1
    assert len(result.warnings) == 1
