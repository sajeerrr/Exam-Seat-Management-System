# tests/conftest.py

import pytest

from engine.models.student import Student
from engine.models.group import Group
from engine.models.classroom import Classroom


def build_students(
    department: str,
    count: int,
    semester: int = 5,
    section: str = "A",
    subject_code: str = "CS301",
    subject_name: str = "Data Structures",
    exam_date: str = "2026-08-01",
    session: str = "FN",
):
    """
    Create dummy students.
    """

    students = []

    for i in range(1, count + 1):
        students.append(
            Student(
                register_no=f"{department}{i:03}",
                name=f"Student {i}",
                department=department,
                semester=semester,
                section=section,
                subject_code=subject_code,
                subject_name=subject_name,
                exam_date=exam_date,
                session=session,
            )
        )

    return students


def build_group(
    department: str,
    count: int,
    semester: int = 5,
    section: str = "A",
    subject_code: str = "CS301",
    subject_name: str = "Data Structures",
    exam_date: str = "2026-08-01",
    session: str = "FN",
):
    """
    Create a group with students.
    """

    return Group(
        group_id=f"{department}-{subject_code}",
        department=department,
        semester=semester,
        section=section,
        subject_code=subject_code,
        subject_name=subject_name,
        exam_date=exam_date,
        session=session,
        students=build_students(
            department,
            count,
            semester,
            section,
            subject_code,
            subject_name,
            exam_date,
            session,
        ),
    )


def build_room(
    room_no: str = "101",
    rows: int = 5,
    benches_per_row: int = 3,
):
    return Classroom(
        room_no=room_no,
        rows=rows,
        benches_per_row=benches_per_row,
    )


@pytest.fixture
def room():
    return build_room()


@pytest.fixture
def group_15():
    return build_group("ME", 15)


@pytest.fixture
def group_30():
    return build_group("ME", 30)


@pytest.fixture
def group_45():
    return build_group("ME", 45)


@pytest.fixture
def group_90():
    return build_group("ME", 90)


@pytest.fixture
def ce_group():
    return build_group("CE", 30)


@pytest.fixture
def cs_group():
    return build_group("CS", 30)


@pytest.fixture
def ee_group():
    return build_group("EE", 30)