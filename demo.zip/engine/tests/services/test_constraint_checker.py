# tests/services/test_constraint_checker.py

import pytest

from engine.algorithms.conflict_graph import ConflictGraph
from engine.models.classroom import Classroom
from engine.models.room_allocation import RoomAllocation
from engine.models.stream_state import StreamState
from engine.models.allocation import Allocation
from engine.services.constraint_checker import ConstraintChecker
from engine.tests.conftest import build_group


# -------------------------------------------------------
# Helpers
# -------------------------------------------------------

def make_room(room_no="101", rows=5, benches_per_row=3):
    classroom = Classroom(room_no=room_no, rows=rows, benches_per_row=benches_per_row)
    return RoomAllocation(classroom)


def make_stream(room, stream="A"):
    return StreamState(room=room, stream=stream, capacity=room.classroom.column_capacity)


# -------------------------------------------------------
# Test 1 – Fresh stream: allocation always allowed
# -------------------------------------------------------

def test_can_allocate_empty_stream():
    graph = ConflictGraph()
    checker = ConstraintChecker(graph)

    room = make_room()
    stream = make_stream(room, "A")

    group = build_group("ME", 15)

    assert checker.can_allocate(group, stream) is True


# -------------------------------------------------------
# Test 2 – Stream already occupied: not allowed
# -------------------------------------------------------

def test_cannot_allocate_occupied_stream():
    graph = ConflictGraph()
    checker = ConstraintChecker(graph)

    room = make_room()
    stream = make_stream(room, "A")

    existing_group = build_group("ME", 15)
    allocation = Allocation(
        group=existing_group,
        students=existing_group.allocate_students(15),
        stream="A",
    )
    room.add_allocation(allocation)

    new_group = build_group("CE", 15)

    assert checker.can_allocate(new_group, stream) is False


# -------------------------------------------------------
# Test 3 – No conflict graph entry: allocation allowed
# -------------------------------------------------------

def test_no_conflict_in_graph_allows_allocation():
    graph = ConflictGraph()  # empty – no conflicts
    checker = ConstraintChecker(graph)

    room = make_room()

    # Place ME in stream A
    me = build_group("ME", 15)
    room.add_allocation(Allocation(group=me, students=me.allocate_students(15), stream="A"))

    # Try to place CE in stream B (no conflict registered)
    ce = build_group("CE", 15)
    stream_b = make_stream(room, "B")

    assert checker.can_allocate(ce, stream_b) is True


# -------------------------------------------------------
# Test 4 – Conflict graph blocks allocation
# -------------------------------------------------------

def test_conflict_graph_blocks_allocation():
    graph = ConflictGraph()
    graph.add_conflict("ME", "CE")
    checker = ConstraintChecker(graph)

    room = make_room()

    me = build_group("ME", 15)
    room.add_allocation(Allocation(group=me, students=me.allocate_students(15), stream="A"))

    ce = build_group("CE", 15)
    stream_b = make_stream(room, "B")

    assert checker.can_allocate(ce, stream_b) is False


# -------------------------------------------------------
# Test 5 – Conflict is bidirectional
# -------------------------------------------------------

def test_conflict_is_bidirectional():
    graph = ConflictGraph()
    graph.add_conflict("CS", "IT")
    checker = ConstraintChecker(graph)

    room = make_room()

    cs = build_group("CS", 15)
    room.add_allocation(Allocation(group=cs, students=cs.allocate_students(15), stream="A"))

    it_group = build_group("IT", 15)
    stream_b = make_stream(room, "B")

    # IT conflicts with CS, so blocked
    assert checker.can_allocate(it_group, stream_b) is False

    room2 = make_room("102")
    it2 = build_group("IT", 15)
    room2.add_allocation(Allocation(group=it2, students=it2.allocate_students(15), stream="A"))

    cs2 = build_group("CS", 15)
    stream2_b = make_stream(room2, "B")

    # CS conflicts with IT, so also blocked
    assert checker.can_allocate(cs2, stream2_b) is False


# -------------------------------------------------------
# Test 6 – Conflict removed: allocation then allowed
# -------------------------------------------------------

def test_removed_conflict_allows_allocation():
    graph = ConflictGraph()
    graph.add_conflict("ME", "CE")
    graph.remove_conflict("ME", "CE")
    checker = ConstraintChecker(graph)

    room = make_room()
    me = build_group("ME", 15)
    room.add_allocation(Allocation(group=me, students=me.allocate_students(15), stream="A"))

    ce = build_group("CE", 15)
    stream_b = make_stream(room, "B")

    assert checker.can_allocate(ce, stream_b) is True


# -------------------------------------------------------
# Test 7 – Multiple existing allocations checked for conflicts
# -------------------------------------------------------

def test_multiple_existing_allocations_checked():
    graph = ConflictGraph()
    graph.add_conflict("EE", "ME")
    checker = ConstraintChecker(graph)

    room = make_room()

    ce = build_group("CE", 15)
    me = build_group("ME", 15)
    room.add_allocation(Allocation(group=ce, students=ce.allocate_students(15), stream="A"))
    room.add_allocation(Allocation(group=me, students=me.allocate_students(15), stream="B"))

    ee = build_group("EE", 15)
    stream_c = make_stream(room, "C")

    # EE conflicts with ME which is already in the room
    assert checker.can_allocate(ee, stream_c) is False
