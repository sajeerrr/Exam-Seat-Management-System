"""
Integration Test Suite  ⭐⭐⭐⭐⭐
===============================================================
Tests the complete allocation pipeline end-to-end:

    AllocationService.execute(context)
            │
            ▼
    PrimaryAllocator          ← fills rooms with full stream-batches
            │
            ▼
    RemainingAllocator        ← places leftover groups via best-fit
            │
            ▼
    SeatGenerator             ← builds the physical seat plan
            │
            ▼
    AllocationValidator       ← asserts no violation slipped through

Every test below runs the *full* pipeline and verifies a distinct
correctness guarantee.
"""

import pytest

from engine.services.allocation_service import AllocationService
from engine.context.allocation_context import AllocationContext
from engine.models.classroom import Classroom
from engine.models.room_allocation import RoomAllocation
from engine.models.remaining_pool import RemainingPool
from engine.models.student import Student
from engine.models.group import Group


# ================================================================
# Shared helpers
# ================================================================

def make_student(dept: str, index: int) -> Student:
    return Student(
        register_no=f"{dept}{index:04d}",
        name=f"Student {index}",
        department=dept,
        semester=6,
        section="A",
        subject_code="SUB101",
        subject_name="Subject",
        exam_date="2026-08-01",
        session="FN",
    )


def make_group(dept: str, count: int) -> Group:
    group = Group(
        group_id=f"{dept}-SUB101",
        department=dept,
        semester=6,
        section="A",
        subject_code="SUB101",
        subject_name="Subject",
        exam_date="2026-08-01",
        session="FN",
    )
    for i in range(1, count + 1):
        group.students.append(make_student(dept, i))
    return group


def make_room(room_no: str, rows: int = 5, benches_per_row: int = 3) -> RoomAllocation:
    """Standard room: 5 rows × 3 benches × 3 seats = 45 capacity, stream_capacity = 15."""
    return RoomAllocation(
        Classroom(room_no=room_no, rows=rows, benches_per_row=benches_per_row)
    )


def make_context(groups: list, rooms: list) -> AllocationContext:
    return AllocationContext(
        groups=groups,
        room_allocations=rooms,
        remaining_pool=RemainingPool(),
    )


def run(groups: list, rooms: list):
    """Run the full pipeline and return (context, seat_plan)."""
    return AllocationService().execute(make_context(groups, rooms))


# ================================================================
# Helper assertions  (reused across multiple tests)
# ================================================================

def assert_no_duplicate_register_numbers(context):
    """Every student appears in at most one room-stream allocation."""
    seen = set()
    for room in context.room_allocations:
        for allocation in room.allocations:
            for student in allocation.students:
                assert student.register_no not in seen, (
                    f"Duplicate register number: {student.register_no}"
                )
                seen.add(student.register_no)


def assert_room_capacity_not_exceeded(context):
    for room in context.room_allocations:
        used = room.used_capacity
        cap  = room.classroom.capacity
        assert used <= cap, (
            f"Room {room.classroom.room_no}: used {used} > capacity {cap}"
        )


def assert_stream_capacity_not_exceeded(context):
    for room in context.room_allocations:
        stream_cap = room.stream_capacity
        for allocation in room.allocations:
            assert allocation.allocated_count <= stream_cap, (
                f"Room {room.classroom.room_no} stream {allocation.stream}: "
                f"{allocation.allocated_count} > stream capacity {stream_cap}"
            )


def assert_no_empty_allocations(context):
    for room in context.room_allocations:
        for allocation in room.allocations:
            assert allocation.allocated_count > 0, (
                f"Empty allocation in room {room.classroom.room_no}, "
                f"stream {allocation.stream}"
            )


def assert_total_student_conservation(context, total_input: int):
    """allocated + genuinely-remaining == original total."""
    allocated = sum(
        a.allocated_count
        for room in context.room_allocations
        for a in room.allocations
    )
    remaining = sum(g.remaining_count for g in context.groups)
    assert allocated + remaining == total_input, (
        f"Student count mismatch: {allocated} allocated + "
        f"{remaining} remaining ≠ {total_input} input"
    )


def assert_pool_groups_genuinely_unallocated(context):
    """Every group in the remaining pool must still have students left."""
    for group in context.remaining_pool.groups:
        assert group.remaining_count > 0, (
            f"Group {group.group_id} is in the remaining pool "
            f"but has remaining_count == 0"
        )


def assert_seat_plan_register_numbers_match_allocations(context, plan):
    """Seat plan must contain exactly the same register numbers as allocations."""
    allocated_reg_nos = {
        student.register_no
        for room in context.room_allocations
        for allocation in room.allocations
        for student in allocation.students
    }
    plan_reg_nos = {seat.student.register_no for seat in plan.seats}
    assert plan_reg_nos == allocated_reg_nos


def run_all_invariant_checks(context, plan, total_input: int):
    """Convenience: run every shared invariant at once."""
    assert_no_duplicate_register_numbers(context)
    assert_room_capacity_not_exceeded(context)
    assert_stream_capacity_not_exceeded(context)
    assert_no_empty_allocations(context)
    assert_total_student_conservation(context, total_input)
    assert_pool_groups_genuinely_unallocated(context)
    assert_seat_plan_register_numbers_match_allocations(context, plan)


# ================================================================
# SCENARIO 1 – Perfect fit
# A single department fills exactly one room (45 students, 1 room).
# Expected: pool empty, all 45 seated, seat plan has 45 entries.
# ================================================================

class TestPerfectFit:

    def setup_method(self):
        self.groups = [make_group("ME", 45)]
        self.rooms  = [make_room("101")]
        self.context, self.plan = run(self.groups, self.rooms)

    def test_all_students_allocated(self):
        assert self.groups[0].remaining_count == 0

    def test_pool_is_empty(self):
        assert self.context.remaining_pool.is_empty()

    def test_seat_plan_has_45_seats(self):
        assert len(self.plan.seats) == 45

    def test_no_duplicate_register_numbers(self):
        assert_no_duplicate_register_numbers(self.context)

    def test_room_capacity_not_exceeded(self):
        assert_room_capacity_not_exceeded(self.context)

    def test_stream_capacity_not_exceeded(self):
        assert_stream_capacity_not_exceeded(self.context)

    def test_no_empty_allocations(self):
        assert_no_empty_allocations(self.context)

    def test_student_conservation(self):
        assert_total_student_conservation(self.context, 45)

    def test_seat_plan_matches_allocations(self):
        assert_seat_plan_register_numbers_match_allocations(self.context, self.plan)


# ================================================================
# SCENARIO 2 – Multiple departments, multiple rooms
# 4 departments × real student counts spread across 3 rooms.
# Exercises primary → remaining handoff.
# ================================================================

class TestMultiDeptMultiRoom:

    # ME=90, CE=75, EE=60, CS=44  → 269 students
    # 6 rooms × 45 = 270 capacity  → should fit entirely
    TOTAL = 90 + 75 + 60 + 44

    def setup_method(self):
        groups = [
            make_group("ME", 90),
            make_group("CE", 75),
            make_group("EE", 60),
            make_group("CS", 44),
        ]
        rooms = [make_room(str(n)) for n in range(101, 107)]  # 6 rooms
        self.context, self.plan = run(groups, rooms)

    def test_student_conservation(self):
        assert_total_student_conservation(self.context, self.TOTAL)

    def test_no_duplicate_register_numbers(self):
        assert_no_duplicate_register_numbers(self.context)

    def test_room_capacity_not_exceeded(self):
        assert_room_capacity_not_exceeded(self.context)

    def test_stream_capacity_not_exceeded(self):
        assert_stream_capacity_not_exceeded(self.context)

    def test_no_empty_allocations(self):
        assert_no_empty_allocations(self.context)

    def test_pool_groups_genuinely_unallocated(self):
        assert_pool_groups_genuinely_unallocated(self.context)

    def test_seat_plan_matches_allocations(self):
        assert_seat_plan_register_numbers_match_allocations(self.context, self.plan)

    def test_all_students_fully_allocated(self):
        """With enough room capacity every student must be seated."""
        total_allocated = sum(
            a.allocated_count
            for room in self.context.room_allocations
            for a in room.allocations
        )
        assert total_allocated == self.TOTAL


# ================================================================
# SCENARIO 3 – Overflow (more students than seats)
# Engine must place as many students as possible and leave the
# rest in the remaining pool — never lose or duplicate anyone.
# ================================================================

class TestOverflow:

    # 200 students, only 3 rooms (135 seats) → 65 must stay in pool
    TOTAL = 200

    def setup_method(self):
        groups = [make_group("ME", self.TOTAL)]
        rooms  = [make_room(str(n)) for n in range(101, 104)]  # 3 rooms = 135 seats
        self.context, self.plan = run(groups, rooms)

    def test_student_conservation(self):
        assert_total_student_conservation(self.context, self.TOTAL)

    def test_no_duplicate_register_numbers(self):
        assert_no_duplicate_register_numbers(self.context)

    def test_room_capacity_not_exceeded(self):
        assert_room_capacity_not_exceeded(self.context)

    def test_stream_capacity_not_exceeded(self):
        assert_stream_capacity_not_exceeded(self.context)

    def test_no_empty_allocations(self):
        assert_no_empty_allocations(self.context)

    def test_pool_groups_genuinely_unallocated(self):
        assert_pool_groups_genuinely_unallocated(self.context)

    def test_seat_plan_matches_allocations(self):
        assert_seat_plan_register_numbers_match_allocations(self.context, self.plan)

    def test_rooms_are_full(self):
        for room in self.context.room_allocations:
            assert room.used_capacity == room.classroom.capacity


# ================================================================
# SCENARIO 4 – Tiny groups (all go via RemainingAllocator)
# Groups smaller than stream_capacity are skipped by Primary and
# must be placed by RemainingAllocator.
# ================================================================

class TestTinyGroups:

    def setup_method(self):
        self.groups = [
            make_group("ME", 5),
            make_group("CE", 7),
            make_group("EE", 3),
            make_group("CS", 12),
        ]
        self.TOTAL = sum(g.strength for g in self.groups)
        rooms = [make_room("101")]
        self.context, self.plan = run(self.groups, rooms)

    def test_student_conservation(self):
        assert_total_student_conservation(self.context, self.TOTAL)

    def test_no_duplicate_register_numbers(self):
        assert_no_duplicate_register_numbers(self.context)

    def test_room_capacity_not_exceeded(self):
        assert_room_capacity_not_exceeded(self.context)

    def test_no_empty_allocations(self):
        assert_no_empty_allocations(self.context)

    def test_seat_plan_matches_allocations(self):
        assert_seat_plan_register_numbers_match_allocations(self.context, self.plan)


# ================================================================
# SCENARIO 5 – Single student
# Edge case: the smallest possible group.
# ================================================================

class TestSingleStudent:

    def setup_method(self):
        self.groups = [make_group("CS", 1)]
        rooms = [make_room("101")]
        self.context, self.plan = run(self.groups, rooms)

    def test_student_is_allocated(self):
        assert self.groups[0].remaining_count == 0

    def test_seat_plan_has_one_seat(self):
        assert len(self.plan.seats) == 1

    def test_no_duplicate_register_numbers(self):
        assert_no_duplicate_register_numbers(self.context)

    def test_room_capacity_not_exceeded(self):
        assert_room_capacity_not_exceeded(self.context)

    def test_pool_is_empty(self):
        assert self.context.remaining_pool.is_empty()


# ================================================================
# SCENARIO 6 – Empty groups, empty rooms
# Pipeline must return gracefully with zero allocations.
# ================================================================

class TestEmptyInputs:

    def test_no_groups_no_allocations(self):
        context, plan = run([], [make_room("101")])
        assert len(plan.seats) == 0
        assert context.remaining_pool.is_empty()

    def test_no_rooms_all_groups_stay_in_pool(self):
        groups = [make_group("ME", 30)]
        context, plan = run(groups, [])
        assert len(plan.seats) == 0
        assert_pool_groups_genuinely_unallocated(context)

    def test_completely_empty_input(self):
        context, plan = run([], [])
        assert len(plan.seats) == 0
        assert context.remaining_pool.is_empty()


# ================================================================
# SCENARIO 7 – Seat plan structural integrity
# Verifies what the SeatGenerator actually writes into each Seat.
# ================================================================

class TestSeatPlanStructure:

    def setup_method(self):
        self.groups = [make_group("ME", 15)]
        rooms = [make_room("101")]
        self.context, self.plan = run(self.groups, rooms)

    def test_every_seat_has_a_student(self):
        for seat in self.plan.seats:
            assert seat.student is not None

    def test_every_seat_has_a_valid_stream(self):
        for seat in self.plan.seats:
            assert seat.stream in ("A", "B", "C")

    def test_every_seat_has_a_positive_bench_number(self):
        for seat in self.plan.seats:
            assert seat.bench_no >= 1

    def test_every_seat_has_a_classroom(self):
        for seat in self.plan.seats:
            assert seat.classroom is not None
            assert seat.room_no == seat.classroom.room_no

    def test_seat_register_numbers_are_unique(self):
        reg_nos = [s.student.register_no for s in self.plan.seats]
        assert len(reg_nos) == len(set(reg_nos))


# ================================================================
# SCENARIO 8 – Validator output is clean after a valid pipeline run
# AllocationService raises on validation failure, so if it returned
# successfully the validator must have found no errors.
# ================================================================

class TestValidatorCleanAfterPipeline:

    def test_validator_reports_success_standard(self):
        groups = [make_group("ME", 45), make_group("CE", 30)]
        rooms  = [make_room("101"), make_room("102")]
        # If the pipeline returns without raising, validation passed
        context, plan = run(groups, rooms)
        assert context is not None and plan is not None

    def test_validator_reports_success_large(self):
        groups = [make_group(d, n) for d, n in
                  [("ME", 90), ("CE", 75), ("EE", 60), ("CS", 45)]]
        rooms  = [make_room(str(n)) for n in range(101, 108)]
        context, plan = run(groups, rooms)
        assert context is not None and plan is not None


# ================================================================
# SCENARIO 9 – Determinism
# Running the same input twice must produce identical allocations.
# ================================================================

class TestDeterminism:

    def _allocated_reg_nos(self, context):
        return sorted(
            student.register_no
            for room in context.room_allocations
            for allocation in room.allocations
            for student in allocation.students
        )

    def test_same_input_same_allocation(self):
        def fresh_run():
            groups = [make_group("ME", 90), make_group("CE", 75)]
            rooms  = [make_room(str(n)) for n in range(101, 105)]
            ctx, _ = run(groups, rooms)
            return self._allocated_reg_nos(ctx)

        assert fresh_run() == fresh_run()


# ================================================================
# SCENARIO 10 – Mixed sizes stress test
# Large realistic dataset: 8 departments, varying counts, 12 rooms.
# All invariants must hold end-to-end.
# ================================================================

class TestStress:

    DEPARTMENTS = [
        ("ME", 120), ("CE", 100), ("EE",  85), ("CS",  75),
        ("IT",  60), ("CH",  55), ("BT",  40), ("AE",  30),
    ]
    TOTAL = sum(n for _, n in DEPARTMENTS)

    def setup_method(self):
        groups = [make_group(dept, count) for dept, count in self.DEPARTMENTS]
        rooms  = [make_room(str(n)) for n in range(101, 113)]  # 12 rooms = 540 seats
        self.context, self.plan = run(groups, rooms)

    def test_student_conservation(self):
        assert_total_student_conservation(self.context, self.TOTAL)

    def test_no_duplicate_register_numbers(self):
        assert_no_duplicate_register_numbers(self.context)

    def test_room_capacity_not_exceeded(self):
        assert_room_capacity_not_exceeded(self.context)

    def test_stream_capacity_not_exceeded(self):
        assert_stream_capacity_not_exceeded(self.context)

    def test_no_empty_allocations(self):
        assert_no_empty_allocations(self.context)

    def test_pool_groups_genuinely_unallocated(self):
        assert_pool_groups_genuinely_unallocated(self.context)

    def test_seat_plan_matches_allocations(self):
        assert_seat_plan_register_numbers_match_allocations(self.context, self.plan)

    def test_rooms_used_to_maximum(self):
        """
        12 rooms × 45 = 540 seats available.
        565 students → some overflow is expected.
        Verify that every seat that CAN be filled IS filled.
        """
        total_room_capacity = sum(
            room.classroom.capacity for room in self.context.room_allocations
        )
        allocated = sum(
            a.allocated_count
            for room in self.context.room_allocations
            for a in room.allocations
        )
        remaining = self.TOTAL - allocated
        # Either fully placed or leftover is ≥ 0 and rooms are not under-used
        assert allocated > 0
        assert allocated + remaining == self.TOTAL
