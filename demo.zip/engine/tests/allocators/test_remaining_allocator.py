# tests/allocators/test_remaining_allocator.py

import pytest

from engine.allocators.remaining_allocator import RemainingAllocator
from engine.context.allocation_context import AllocationContext
from engine.models.classroom import Classroom
from engine.models.room_allocation import RoomAllocation
from engine.models.remaining_pool import RemainingPool
from engine.tests.conftest import build_group


# -------------------------------------------------------
# Helpers
# -------------------------------------------------------

def build_room(room_no, rows=5, benches_per_row=3):
    classroom = Classroom(
        room_no=room_no,
        rows=rows,
        benches_per_row=benches_per_row,
    )
    return RoomAllocation(classroom)


def build_context(groups, rooms):
    context = AllocationContext(
        groups=groups,
        room_allocations=rooms,
        remaining_pool=RemainingPool(),
    )
    context.initialize_streams()
    return context


# -------------------------------------------------------
# Test 1 – Small group fits into an available stream
# -------------------------------------------------------

def test_small_group_is_allocated():
    group = build_group("ME", 10)

    context = build_context([], [build_room("101")])
    context.remaining_pool.add(group)

    RemainingAllocator().execute(context)

    total = sum(
        a.allocated_count
        for room in context.room_allocations
        for a in room.allocations
    )

    assert total == 10
    assert context.remaining_pool.is_empty()


# -------------------------------------------------------
# Test 2 – Group is removed from pool after allocation
# -------------------------------------------------------

def test_group_removed_from_pool():
    group = build_group("CE", 8)

    context = build_context([], [build_room("101")])
    context.remaining_pool.add(group)

    RemainingAllocator().execute(context)

    assert group not in context.remaining_pool.groups


# -------------------------------------------------------
# Test 3 – Group too large for any available stream stays in pool
# -------------------------------------------------------

def test_oversized_group_stays_in_pool():
    group = build_group("EE", 50)   # column_capacity = 15; group won't fit

    context = build_context([], [build_room("101")])
    context.remaining_pool.add(group)

    RemainingAllocator().execute(context)

    # Nothing should be allocated
    total = sum(
        a.allocated_count
        for room in context.room_allocations
        for a in room.allocations
    )
    assert total == 0
    assert group in context.remaining_pool.groups


# -------------------------------------------------------
# Test 4 – Best-fit: prefers stream with minimum waste
# -------------------------------------------------------

def test_best_fit_stream_chosen():
    group = build_group("CS", 5)

    # Two rooms; after partial primary allocation the remaining group
    # should land in the stream with the tightest fit.
    rooms = [build_room("101"), build_room("102")]
    context = build_context([], rooms)
    context.remaining_pool.add(group)

    RemainingAllocator().execute(context)

    assert group not in context.remaining_pool.groups
    assert group.remaining_count == 0


# -------------------------------------------------------
# Test 5 – Multiple small groups all placed
# -------------------------------------------------------

def test_multiple_small_groups_all_placed():
    g1 = build_group("ME", 5)
    g2 = build_group("CE", 7)
    g3 = build_group("CS", 3)

    context = build_context([], [build_room("101")])
    for g in [g1, g2, g3]:
        context.remaining_pool.add(g)

    RemainingAllocator().execute(context)

    # All groups should be fully allocated (5+7+3=15 == column_capacity)
    total = sum(
        a.allocated_count
        for room in context.room_allocations
        for a in room.allocations
    )
    assert total == 15


# -------------------------------------------------------
# Test 6 – Empty pool leaves rooms unchanged
# -------------------------------------------------------

def test_empty_pool_no_change():
    context = build_context([], [build_room("101")])

    RemainingAllocator().execute(context)

    total = sum(
        len(room.allocations) for room in context.room_allocations
    )
    assert total == 0


# -------------------------------------------------------
# Test 7 – No rooms: group stays in pool
# -------------------------------------------------------

def test_no_rooms_group_stays_in_pool():
    group = build_group("ME", 10)

    context = build_context([], [])
    context.remaining_pool.add(group)

    RemainingAllocator().execute(context)

    assert group in context.remaining_pool.groups


# -------------------------------------------------------
# Test 8 – Student count preserved after allocation
# -------------------------------------------------------

def test_remaining_count_zero_after_allocation():
    group = build_group("ME", 12)

    context = build_context([], [build_room("101")])
    context.remaining_pool.add(group)

    RemainingAllocator().execute(context)

    assert group.remaining_count == 0
