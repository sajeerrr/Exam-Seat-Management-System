# tests/allocators/test_primary_allocator.py

import pytest

from engine.allocators.primary_allocator import PrimaryAllocator
from engine.context.allocation_context import AllocationContext

from engine.models.classroom import Classroom
from engine.models.room_allocation import RoomAllocation
from engine.models.remaining_pool import RemainingPool

from engine.tests.conftest import build_group


# -------------------------------------------------------
# Helpers
# -------------------------------------------------------

def build_room(room_no):
    classroom = Classroom(
        room_no=room_no,
        rows=5,
        benches_per_row=3,
    )
    return RoomAllocation(classroom)


def build_context(groups, rooms):

    context = AllocationContext(
        groups=groups,
        room_allocations=rooms,
        remaining_pool=RemainingPool(),
    )

    context.initialize_streams()

    return context


# -------------------------------------------------------
# Tests
# -------------------------------------------------------

def test_single_large_group():

    groups = [
        build_group("ME", 90)
    ]

    rooms = [
        build_room("101"),
        build_room("102"),
    ]

    context = build_context(groups, rooms)

    allocator = PrimaryAllocator()

    allocator.execute(context)

    total = sum(
        allocation.allocated_count
        for room in context.room_allocations
        for allocation in room.allocations
    )

    assert total == 90
    assert groups[0].remaining_count == 0


def test_partial_group_goes_to_remaining_pool():

    groups = [
        build_group("ME", 44)
    ]

    rooms = [
        build_room("101")
    ]

    context = build_context(groups, rooms)

    PrimaryAllocator().execute(context)

    total = sum(
        allocation.allocated_count
        for room in context.room_allocations
        for allocation in room.allocations
    )

    # PrimaryAllocator places full stream-batches (column_capacity = 15).
    # 44 // 15 = 2 full batches → 30 allocated, 14 remaining → sent to pool.
    assert total == 30
    assert groups[0].remaining_count == 14

    assert groups[0] in context.remaining_pool.groups


def test_small_group_skipped():

    groups = [
        build_group("ME", 10)
    ]

    rooms = [
        build_room("101")
    ]

    context = build_context(groups, rooms)

    PrimaryAllocator().execute(context)

    total = sum(
        len(room.allocations)
        for room in context.room_allocations
    )

    assert total == 0

    assert groups[0] in context.remaining_pool.groups


def test_multiple_departments():

    groups = [
        build_group("ME", 90),
        build_group("CE", 90),
        build_group("CS", 90),
    ]

    rooms = [
        build_room("101"),
        build_room("102"),
        build_room("103"),
        build_room("104"),
        build_room("105"),
        build_room("106"),
    ]

    context = build_context(groups, rooms)

    PrimaryAllocator().execute(context)

    total = sum(
        allocation.allocated_count
        for room in context.room_allocations
        for allocation in room.allocations
    )

    assert total == 270


def test_stream_capacity_never_exceeded():

    groups = [
        build_group("ME", 90)
    ]

    rooms = [
        build_room("101"),
        build_room("102"),
    ]

    context = build_context(groups, rooms)

    PrimaryAllocator().execute(context)

    for room in context.room_allocations:
        for allocation in room.allocations:
            assert allocation.allocated_count <= 15


def test_room_capacity_never_exceeded():

    groups = [
        build_group("ME", 200)
    ]

    rooms = [
        build_room("101"),
        build_room("102"),
        build_room("103"),
        build_room("104"),
        build_room("105"),
    ]

    context = build_context(groups, rooms)

    PrimaryAllocator().execute(context)

    for room in context.room_allocations:
        assert room.used_capacity <= room.classroom.capacity


def test_no_duplicate_stream_assignment():

    groups = [
        build_group("ME", 45)
    ]

    rooms = [
        build_room("101")
    ]

    context = build_context(groups, rooms)

    PrimaryAllocator().execute(context)

    used = []

    for room in context.room_allocations:
        for stream, allocation in room.streams.items():

            if allocation is not None:
                assert stream not in used
                used.append(stream)


def test_remaining_pool_empty_after_full_allocation():

    groups = [
        build_group("ME", 45)
    ]

    rooms = [
        build_room("101")
    ]

    context = build_context(groups, rooms)

    PrimaryAllocator().execute(context)

    assert context.remaining_pool.is_empty()


def test_all_students_allocated_once():

    group = build_group("ME", 45)

    rooms = [
        build_room("101")
    ]

    context = build_context([group], rooms)

    PrimaryAllocator().execute(context)

    students = []

    for room in context.room_allocations:
        for allocation in room.allocations:
            students.extend(allocation.students)

    register_numbers = [
        student.register_no
        for student in students
    ]

    assert len(register_numbers) == len(set(register_numbers))