# tests/validators/test_allocation_validator.py

import pytest

from engine.validators.allocation_validator import AllocationValidator
from engine.context.allocation_context import AllocationContext
from engine.models.classroom import Classroom
from engine.models.room_allocation import RoomAllocation
from engine.models.remaining_pool import RemainingPool
from engine.models.allocation import Allocation
from engine.tests.conftest import build_group


# -------------------------------------------------------
# Helpers
# -------------------------------------------------------

def make_room(room_no, rows=5, benches_per_row=3):
    return RoomAllocation(Classroom(room_no=room_no, rows=rows, benches_per_row=benches_per_row))


def make_context(groups, rooms):
    ctx = AllocationContext(
        groups=groups,
        room_allocations=rooms,
        remaining_pool=RemainingPool(),
    )
    ctx.initialize_streams()
    return ctx


# -------------------------------------------------------
# Test 1 – Clean allocation: success, no errors
# -------------------------------------------------------

def test_valid_allocation_passes():
    group = build_group("ME", 15)
    room = make_room("101")
    context = make_context([group], [room])

    students = group.allocate_students(15)
    room.add_allocation(Allocation(group=group, students=students, stream="A"))

    result = AllocationValidator().validate(context)

    assert result.success is True
    assert result.errors == []


# -------------------------------------------------------
# Test 2 – Duplicate student triggers error
# -------------------------------------------------------

def test_duplicate_student_triggers_error():
    group = build_group("ME", 15)
    room = make_room("101")
    context = make_context([group], [room])

    students = group.allocate_students(15)
    # Add same student list to two different streams to force duplicates
    room.add_allocation(Allocation(group=group, students=students, stream="A"))
    room.add_allocation(Allocation(group=group, students=students, stream="B"))

    result = AllocationValidator().validate(context)

    assert result.success is False
    assert any("Duplicate" in e for e in result.errors)


# -------------------------------------------------------
# Test 3 – Capacity exceeded triggers error
# -------------------------------------------------------

def test_capacity_exceeded_triggers_error():
    group = build_group("ME", 60)   # 60 students, room fits 45
    room = make_room("101")
    context = make_context([group], [room])

    # Force 60 students into streams (bypassing allocator logic)
    chunk = group.allocate_students(20)
    room.add_allocation(Allocation(group=group, students=chunk, stream="A"))
    chunk2 = group.allocate_students(20)
    room.add_allocation(Allocation(group=group, students=chunk2, stream="B"))
    chunk3 = group.allocate_students(20)
    room.add_allocation(Allocation(group=group, students=chunk3, stream="C"))

    result = AllocationValidator().validate(context)

    assert result.success is False
    assert any("exceeds capacity" in e for e in result.errors)


# -------------------------------------------------------
# Test 4 – Empty allocation is valid
# -------------------------------------------------------

def test_empty_allocation_is_valid():
    context = make_context([], [make_room("101")])

    result = AllocationValidator().validate(context)

    assert result.success is True


# -------------------------------------------------------
# Test 5 – Group in pool with 0 remaining generates warning
# -------------------------------------------------------

def test_pool_group_with_zero_remaining_warns():
    group = build_group("ME", 15)
    group.allocate_students(15)   # fully allocated

    context = make_context([group], [make_room("101")])
    context.remaining_pool.add(group)   # erroneously still in pool

    result = AllocationValidator().validate(context)

    assert any("unnecessarily remained" in w for w in result.warnings)


# -------------------------------------------------------
# Test 6 – Stream capacity exceeded triggers error
# -------------------------------------------------------

def test_stream_capacity_exceeded_triggers_error():
    group = build_group("ME", 20)   # 20 > stream_capacity (15)
    room = make_room("101")
    context = make_context([group], [room])

    students = group.allocate_students(20)
    room.add_allocation(Allocation(group=group, students=students, stream="A"))

    result = AllocationValidator().validate(context)

    assert result.success is False
    assert any("exceeded stream capacity" in e for e in result.errors)
