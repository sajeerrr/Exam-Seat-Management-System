# tests/algorithms/test_conflict_graph.py

import pytest

from engine.algorithms.conflict_graph import ConflictGraph


# -------------------------------------------------------
# Test 1 – Empty graph has no conflicts
# -------------------------------------------------------

def test_empty_graph_no_conflict():
    graph = ConflictGraph()
    assert graph.has_conflict("ME", "CE") is False


# -------------------------------------------------------
# Test 2 – Single conflict is recorded
# -------------------------------------------------------

def test_add_conflict():
    graph = ConflictGraph()
    graph.add_conflict("ME", "CE")
    assert graph.has_conflict("ME", "CE") is True


# -------------------------------------------------------
# Test 3 – Conflict is bidirectional
# -------------------------------------------------------

def test_conflict_is_bidirectional():
    graph = ConflictGraph()
    graph.add_conflict("CS", "IT")
    assert graph.has_conflict("CS", "IT") is True
    assert graph.has_conflict("IT", "CS") is True


# -------------------------------------------------------
# Test 4 – No conflict between unrelated departments
# -------------------------------------------------------

def test_unrelated_departments_no_conflict():
    graph = ConflictGraph()
    graph.add_conflict("ME", "CE")
    assert graph.has_conflict("ME", "CS") is False
    assert graph.has_conflict("CS", "EE") is False


# -------------------------------------------------------
# Test 5 – Multiple conflicts stored independently
# -------------------------------------------------------

def test_multiple_conflicts():
    graph = ConflictGraph()
    graph.add_conflict("ME", "CE")
    graph.add_conflict("CS", "IT")
    assert graph.has_conflict("ME", "CE") is True
    assert graph.has_conflict("CS", "IT") is True
    assert graph.has_conflict("ME", "CS") is False


# -------------------------------------------------------
# Test 6 – Remove conflict clears both directions
# -------------------------------------------------------

def test_remove_conflict():
    graph = ConflictGraph()
    graph.add_conflict("ME", "CE")
    graph.remove_conflict("ME", "CE")
    assert graph.has_conflict("ME", "CE") is False
    assert graph.has_conflict("CE", "ME") is False


# -------------------------------------------------------
# Test 7 – Remove non-existent conflict is safe (no error)
# -------------------------------------------------------

def test_remove_nonexistent_conflict_is_safe():
    graph = ConflictGraph()
    graph.remove_conflict("ME", "CE")   # should not raise


# -------------------------------------------------------
# Test 8 – Duplicate add_conflict is idempotent
# -------------------------------------------------------

def test_duplicate_add_is_idempotent():
    graph = ConflictGraph()
    graph.add_conflict("ME", "CE")
    graph.add_conflict("ME", "CE")
    assert graph.has_conflict("ME", "CE") is True


# -------------------------------------------------------
# Test 9 – Self-conflict can be stored if needed
# -------------------------------------------------------

def test_self_conflict():
    graph = ConflictGraph()
    graph.add_conflict("ME", "ME")
    assert graph.has_conflict("ME", "ME") is True
