students = [
    Student("23ME001", "Arun",  "ME", "6A", "QUALITY"),
    Student("23ME002", "Rahul", "ME", "6A", "QUALITY"),
    Student("23ME003", "Akhil", "ME", "6A", "QUALITY"),

    Student("23CE001", "Anu",   "CE", "6A", "MATHS"),
    Student("23CE002", "Diya",  "CE", "6A", "MATHS"),
]