from exam_seating_engine.tests.sample_data import groups, classrooms
from exam_seating_engine.engine.primary_allocator import PrimaryAllocator

print("=" * 60)
print("INPUT GROUPS")
print("=" * 60)

for group in groups:
    print(
        f"{group.department}{group.semester}{group.section} "
        f"{group.subject_name} "
        f"Strength = {group.strength}"
    )

print("\n")

print("=" * 60)
print("CLASSROOMS")
print("=" * 60)

for room in classrooms:
    print(
        f"{room.room_no} "
        f"Capacity = {room.capacity} "
        f"Stream Capacity = {room.stream_capacity}"
    )

print("\n")

allocator = PrimaryAllocator()

room_allocations, remaining_pool = allocator.allocate(
    groups,
    classrooms
)

print("=" * 60)
print("ROOM ALLOCATIONS")
print("=" * 60)

for room in room_allocations:

    print(f"\n{room.classroom.room_no}")

    for allocation in room.allocations:

        group = allocation.group

        print(
            f"{allocation.stream}  "
            f"{group.department}{group.semester}{group.section}  "
            f"{allocation.allocated_count}"
        )

print("\n")

print("=" * 60)
print("REMAINING POOL")
print("=" * 60)

if not remaining_pool.groups:
    print("No Remaining Groups")

for group in remaining_pool.groups:
    print(
        f"{group.department}{group.semester}{group.section} "
        f"Remaining = {group.remaining_count}"
    )