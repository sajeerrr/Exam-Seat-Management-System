from engine.models.group import Group
from engine.models.student import Student


def build_group(name, count):
    """
    Build a Group with `count` dummy students so that
    group.remaining_count == count (since no students are allocated yet).
    """

    group = Group(
        group_id=name,
        department=name,
        semester=6,
        section="A",
        subject_code="SUB",
        subject_name="Subject",
        exam_date="2026-01-01",
        session="FN",
    )

    for i in range(count):
        group.students.append(
            Student(
                register_no=f"{name}{i:04d}",
                name=f"Student {i}",
                department=name,
                semester=6,
                section="A",
                subject_code="SUB",
                subject_name="Subject",
                exam_date="2026-01-01",
                session="FN",
            )
        )

    return group
