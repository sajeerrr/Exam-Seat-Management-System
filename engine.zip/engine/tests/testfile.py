# pyrefly: ignore [missing-import]
import pytest

from engine.allocators.primary_allocator import PrimaryAllocator
from engine.context.allocation_context import AllocationContext

from engine.models.student import Student
from engine.models.group import Group
from engine.models.classroom import Classroom
from engine.models.room_allocation import RoomAllocation
from engine.models.remaining_pool import RemainingPool


# -------------------------------------------------------
# Helper Functions
# -------------------------------------------------------

def build_group(name, count):

    students = []

    for i in range(count):

        students.append(

            Student(

                register_no=f"{name}{i+1:03}",

                name=f"Student{i+1}",

                department=name,

                semester=6,

                section="A",

                subject_code="SUB101",

                subject_name="Subject",

                exam_date="2026-01-01",

                session="FN",

            )

        )

    group = Group(

        group_id=name,

        department=name,

        semester=6,

        section="A",

        subject_code="SUB101",

        subject_name="Subject",

        exam_date="2026-01-01",

        session="FN",

    )

    group.students = students

    return group

def build_room(room_no):

    classroom = Classroom(
        room_no=room_no,
        rows=5,
        benches_per_row=3,
        seats_per_bench=3
    )

    return RoomAllocation(classroom)


# -------------------------------------------------------
# Test Data
# -------------------------------------------------------

def build_context():

    groups = [

        build_group("ME", 90),

        build_group("CE", 75),

        build_group("EE", 60),

        build_group("CS", 44),

    ]

    rooms = [

        build_room("101"),

        build_room("102"),

        build_room("103"),

    ]

    context = AllocationContext(

        groups=groups,

        room_allocations=rooms,

        remaining_pool=RemainingPool(),

    )

    context.initialize_streams()

    return context


# -------------------------------------------------------
# Test 1
# -------------------------------------------------------

def test_primary_allocator_runs():

    context = build_context()

    PrimaryAllocator().execute(context)

    total = 0

    for room in context.room_allocations:

        total += len(room.allocations)

    assert total > 0


# -------------------------------------------------------
# Test 2
# -------------------------------------------------------

def test_room_capacity_not_exceeded():

    context = build_context()

    PrimaryAllocator().execute(context)

    for room in context.room_allocations:

        allocated = sum(
            a.allocated_count
            for a in room.allocations
        )

        assert allocated <= room.classroom.capacity


# -------------------------------------------------------
# Test 3
# -------------------------------------------------------

def test_stream_capacity():

    context = build_context()

    PrimaryAllocator().execute(context)

    for room in context.room_allocations:

        for allocation in room.allocations:

            assert (
                allocation.allocated_count
                == room.stream_capacity
            )


# -------------------------------------------------------
# Test 4
# -------------------------------------------------------

def test_remaining_pool_exists():

    context = build_context()

    PrimaryAllocator().execute(context)

    assert context.remaining_pool is not None


# -------------------------------------------------------
# Test 5
# -------------------------------------------------------

def test_remaining_students_updated():

    context = build_context()

    PrimaryAllocator().execute(context)

    for group in context.groups:

        assert group.remaining_count >= 0


# -------------------------------------------------------
# Test 6
# -------------------------------------------------------

def test_no_duplicate_streams():

    context = build_context()

    PrimaryAllocator().execute(context)

    for room in context.room_allocations:

        used = []

        for allocation in room.allocations:

            assert allocation.stream not in used

            used.append(allocation.stream)


# -------------------------------------------------------
# Test 7
# -------------------------------------------------------

def test_room_remaining_capacity():

    context = build_context()

    PrimaryAllocator().execute(context)

    for room in context.room_allocations:

        allocated = sum(
            a.allocated_count
            for a in room.allocations
        )

        assert (

            room.remaining_capacity

            == room.classroom.capacity - allocated

        )


# -------------------------------------------------------
# Test 8
# -------------------------------------------------------

def test_empty_groups():

    context = AllocationContext(

        groups=[],

        room_allocations=[

            build_room("101")

        ],

        remaining_pool=RemainingPool(),

    )

    PrimaryAllocator().execute(context)

    assert len(context.room_allocations[0].allocations) == 0


# -------------------------------------------------------
# Test 9
# -------------------------------------------------------

def test_empty_rooms():

    context = AllocationContext(

        groups=[

            build_group("ME", 90)

        ],

        room_allocations=[],

        remaining_pool=RemainingPool(),

    )

    context.initialize_streams()

    PrimaryAllocator().execute(context)

    assert len(context.remaining_pool.groups) == 1


# -------------------------------------------------------
# Test 10
# -------------------------------------------------------

def test_total_allocated_students():

    context = build_context()

    PrimaryAllocator().execute(context)

    allocated = 0

    for room in context.room_allocations:

        allocated += sum(

            a.allocated_count

            for a in room.allocations

        )

    remaining = sum(

        g.remaining_count

        for g in context.groups

    )

    original = 90 + 75 + 60 + 44

    assert allocated + remaining == original