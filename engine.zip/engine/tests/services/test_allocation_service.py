# tests/services/test_allocation_service.py
# End-to-end integration tests for AllocationService

import pytest

from engine.services.allocation_service import AllocationService
from engine.context.allocation_context import AllocationContext
from engine.models.classroom import Classroom
from engine.models.room_allocation import RoomAllocation
from engine.models.remaining_pool import RemainingPool
from engine.tests.conftest import build_group


# -------------------------------------------------------
# Helpers
# -------------------------------------------------------

def make_room(room_no, rows=5, benches_per_row=3):
    return RoomAllocation(Classroom(room_no=room_no, rows=rows, benches_per_row=benches_per_row))


def make_context(groups, rooms):
    return AllocationContext(
        groups=groups,
        room_allocations=rooms,
        remaining_pool=RemainingPool(),
    )


# -------------------------------------------------------
# Test 1 – Full allocation: no remaining students
# -------------------------------------------------------

def test_full_allocation_no_remaining():
    groups = [build_group("ME", 45)]
    rooms  = [make_room("101")]

    context, plan = AllocationService().execute(make_context(groups, rooms))

    total = sum(
        a.allocated_count
        for room in context.room_allocations
        for a in room.allocations
    )

    assert total == 45
    assert context.remaining_pool.is_empty()


# -------------------------------------------------------
# Test 2 – Seat plan produced with correct count
# -------------------------------------------------------

def test_seat_plan_has_correct_student_count():
    groups = [build_group("ME", 30), build_group("CE", 15)]
    rooms  = [make_room("101")]

    context, plan = AllocationService().execute(make_context(groups, rooms))

    assert len(plan.seats) == 45


# -------------------------------------------------------
# Test 3 – No duplicate register numbers in seat plan
# -------------------------------------------------------

def test_no_duplicate_students_in_plan():
    groups = [build_group("ME", 45)]
    rooms  = [make_room("101")]

    context, plan = AllocationService().execute(make_context(groups, rooms))

    reg_nos = [s.student.register_no for s in plan.seats]
    assert len(reg_nos) == len(set(reg_nos))


# -------------------------------------------------------
# Test 4 – Multi-room, large cohort
# -------------------------------------------------------

def test_multi_room_large_cohort():
    groups = [
        build_group("ME", 90),
        build_group("CE", 75),
        build_group("CS", 45),
    ]
    rooms = [make_room(str(i)) for i in range(101, 108)]  # 7 rooms × 45 = 315 seats

    context, plan = AllocationService().execute(make_context(groups, rooms))

    total_allocated = sum(
        a.allocated_count
        for room in context.room_allocations
        for a in room.allocations
    )
    total_remaining = sum(g.remaining_count for g in context.groups)

    assert total_allocated + total_remaining == 90 + 75 + 45


# -------------------------------------------------------
# Test 5 – Room capacity never exceeded
# -------------------------------------------------------

def test_room_capacity_not_exceeded():
    groups = [build_group("ME", 200)]
    rooms  = [make_room(str(i)) for i in range(101, 106)]  # 5 rooms

    context, plan = AllocationService().execute(make_context(groups, rooms))

    for room in context.room_allocations:
        assert room.used_capacity <= room.classroom.capacity


# -------------------------------------------------------
# Test 6 – Empty input: valid, empty plan returned
# -------------------------------------------------------

def test_empty_input_returns_empty_plan():
    context, plan = AllocationService().execute(make_context([], [make_room("101")]))

    assert len(plan.seats) == 0
    assert context.remaining_pool.is_empty()
